
// AES encryption placeholder
export function encrypt(text, key) {
  return text; // TODO
}
export function decrypt(cipher, key) {
  return cipher; // TODO
}
