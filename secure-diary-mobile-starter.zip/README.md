
# Secure Diary Mobile App

Privacy-first mobile diary app.
- Google Sign-In
- Google Drive (AppData) storage
- Local encryption
- Offline-first

## Run
npm install
npx expo start
